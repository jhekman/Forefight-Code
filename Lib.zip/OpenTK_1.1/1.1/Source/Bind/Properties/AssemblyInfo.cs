﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Generator.Bind")]
[assembly: AssemblyDescription("Generates C# bindings for the the Open Toolkit Library")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0d681958-ca78-4a67-b71c-ff8755488e23")]
